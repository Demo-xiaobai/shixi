---
description: Learn about BaseDataset in Ultralytics YOLO, a flexible dataset class for object detection. Maximize your YOLO performance with custom datasets.
keywords: BaseDataset, Ultralytics YOLO, object detection, real-world applications, documentation
---

## BaseDataset
---
### ::: ultralytics.yolo.data.base.BaseDataset
<br><br>
