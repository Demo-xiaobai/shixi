---
description: 'Learn about Ultralytics YOLO files and directory utilities: WorkingDirectory, file_age, file_size, and make_dirs.'
keywords: YOLO, object detection, file utils, file age, file size, working directory, make directories, Ultralytics Docs
---

## WorkingDirectory
---
### ::: ultralytics.yolo.utils.files.WorkingDirectory
<br><br>

## increment_path
---
### ::: ultralytics.yolo.utils.files.increment_path
<br><br>

## file_age
---
### ::: ultralytics.yolo.utils.files.file_age
<br><br>

## file_date
---
### ::: ultralytics.yolo.utils.files.file_date
<br><br>

## file_size
---
### ::: ultralytics.yolo.utils.files.file_size
<br><br>

## get_latest_run
---
### ::: ultralytics.yolo.utils.files.get_latest_run
<br><br>

## make_dirs
---
### ::: ultralytics.yolo.utils.files.make_dirs
<br><br>
