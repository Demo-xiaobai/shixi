---
description: Learn how to use NASPredictor in Ultralytics YOLO for deploying efficient CNN models with search algorithms in neural architecture search.
keywords: Ultralytics YOLO, NASPredictor, neural architecture search, efficient CNN models, search algorithms
---

## NASPredictor
---
### ::: ultralytics.yolo.nas.predict.NASPredictor
<br><br>
