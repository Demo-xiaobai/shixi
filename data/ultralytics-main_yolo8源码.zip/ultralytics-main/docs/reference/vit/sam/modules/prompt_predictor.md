---
description: Learn about PromptPredictor - a module in Ultralytics VIT SAM that predicts image captions based on prompts. Get started today!.
keywords: PromptPredictor, Ultralytics, YOLO, VIT SAM, image captioning, deep learning, computer vision
---

## PromptPredictor
---
### ::: ultralytics.vit.sam.modules.prompt_predictor.PromptPredictor
<br><br>