---
description: Learn about HungarianMatcher and inverse_sigmoid functions in the Ultralytics YOLO Docs. Improve your object detection skills today!.
keywords: Ultralytics, YOLO, object detection, HungarianMatcher, inverse_sigmoid
---

## HungarianMatcher
---
### ::: ultralytics.vit.utils.ops.HungarianMatcher
<br><br>

## get_cdn_group
---
### ::: ultralytics.vit.utils.ops.get_cdn_group
<br><br>

## inverse_sigmoid
---
### ::: ultralytics.vit.utils.ops.inverse_sigmoid
<br><br>