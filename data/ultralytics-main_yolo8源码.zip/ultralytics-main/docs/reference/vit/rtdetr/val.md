---
description: Documentation for RTDETRValidator data validation tool in Ultralytics RTDETRDataset.
keywords: RTDETRDataset, RTDETRValidator, data validation, documentation
---

## RTDETRDataset
---
### ::: ultralytics.vit.rtdetr.val.RTDETRDataset
<br><br>

## RTDETRValidator
---
### ::: ultralytics.vit.rtdetr.val.RTDETRValidator
<br><br>