---
description: Improve object tracking with KalmanFilterXYAH in Ultralytics YOLO - an efficient and accurate algorithm for state estimation.
keywords: KalmanFilterXYAH, Ultralytics Docs, Kalman filter algorithm, object tracking, computer vision, YOLO
---

## KalmanFilterXYAH
---
### ::: ultralytics.tracker.utils.kalman_filter.KalmanFilterXYAH
<br><br>

## KalmanFilterXYWH
---
### ::: ultralytics.tracker.utils.kalman_filter.KalmanFilterXYWH
<br><br>
